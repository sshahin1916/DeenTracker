import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { 
    Check, Star, Heart, BookOpen, Moon, Sun, 
    AlertTriangle, Frown, XCircle, Activity, 
    TrendingUp, Calendar, Trash2, Shield, Plus, Minus, Award,
    Settings, X, Send
} from 'lucide-react';

// --- Custom CSS for Animations ---
const customStyles = `
@keyframes shake {
    0%, 100% { transform: translateX(0); }
    25% { transform: translateX(-10px) rotate(-2deg); }
    50% { transform: translateX(10px) rotate(2deg); }
    75% { transform: translateX(-10px) rotate(-2deg); }
}
.animate-shake {
    animation: shake 0.4s cubic-bezier(.36,.07,.19,.97) both;
}
@keyframes floatUp {
    0% { opacity: 1; transform: translateY(0) scale(1) rotate(0deg); }
    100% { opacity: 0; transform: translateY(-100px) scale(1.5) rotate(45deg); }
}
.particle {
    position: absolute;
    pointer-events: none;
    animation: floatUp 1.2s ease-out forwards;
}
@keyframes pop {
    0% { transform: scale(0.95); }
    50% { transform: scale(1.05); }
    100% { transform: scale(1); }
}
.animate-pop {
    animation: pop 0.3s ease-in-out;
}
`;

const T = {
    en: {
        appTitle: "Deen Tracker", day: "Day", of: "of", dashboard: "Dashboard", tasks: "Tasks", history: "History", summary: "Daily Progress Summary", namazComplete: "Namaz Completion", goodAchieved: "Good Deeds Achieved", penalties: "Penalties applied", prayers: "Obligatory Prayers", goodDeeds: "Islamic Good Deeds", badDeeds: "Actions to Avoid (Sins)", badDesc: "Logging these will heavily impact your daily score.", customGood: "Other Good Deed", customBad: "Other Bad Deed", add: "Add", historyTitle: "7-Day Cycle History", historyDesc: "Your data resets automatically on the 8th day.", noHistory: "No history yet. Check back tomorrow!", settings: "Settings", darkMode: "Dark Mode", language: "Language", close: "Close", customPlaceholder: "Describe your deed...", pts: "pts", penaltyInfo: "due to negative actions. Seek forgiveness to protect your spiritual state."
    },
    bn: {
        appTitle: "দ্বীন ট্র্যাকার", day: "দিন", of: "এর", dashboard: "ড্যাশবোর্ড", tasks: "টাস্ক", history: "হিস্ট্রি", summary: "দৈনিক অগ্রগতি সারসংক্ষেপ", namazComplete: "নামাজ সম্পন্ন", goodAchieved: "সৎকর্ম অর্জিত", penalties: "জরিমানা প্রয়োগ করা হয়েছে (-", prayers: "ফরজ নামাজ", goodDeeds: "ইসলামিক সৎকর্ম", badDeeds: "বর্জনীয় কাজ (পাপ)", badDesc: "এগুলো আপনার স্কোরে নেতিবাচক প্রভাব ফেলবে। ক্ষমা প্রার্থনা করুন।", customGood: "অন্যান্য ভালো কাজ", customBad: "অন্যান্য খারাপ কাজ", add: "যুক্ত করুন", historyTitle: "৭ দিনের ইতিহাস", historyDesc: "আপনার ডেটা ৮ম দিনে স্বয়ংক্রিয়ভাবে রিসেট হবে।", noHistory: "কোন ইতিহাস নেই। আগামীকাল চেক করুন!", settings: "সেটিংস", darkMode: "ডার্ক মোড", language: "ভাষা", close: "বন্ধ করুন", customPlaceholder: "বিবরণ লিখুন...", pts: "পয়েন্ট", penaltyInfo: "নেতিবাচক কাজের জন্য। ক্ষমা প্রার্থনা করুন।"
    }
};

// --- Data Models & Constants ---
const NAMAZ_LIST = [
    { id: 'fajr', name: 'Fajr', bn: 'ফজর', icon: Moon },
    { id: 'dhuhr', name: 'Dhuhr', bn: 'যোহর', icon: Sun },
    { id: 'asr', name: 'Asr', bn: 'আসর', icon: Activity },
    { id: 'maghrib', name: 'Maghrib', bn: 'মাগরিব', icon: SunsetIcon },
    { id: 'isha', name: 'Isha', bn: 'এশা', icon: Star },
];

function SunsetIcon(props) {
    return (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
            <path d="M12 10v4" /><path d="M16 10l-4 4" /><path d="M8 10l4 4" />
            <path d="M22 17H2" /><path d="M12 2v2" /><path d="M5 4.5l1.5 1.5" /><path d="M19 4.5l-1.5 1.5" />
        </svg>
);
}

const GOOD_DEEDS = [
    { id: 'sadaqah', name: 'Sadaqah (Charity)', bn: 'সদকা (দান)', type: 'boolean', weight: 15, icon: Heart },
    { id: 'quran', name: 'Quran Recitation', bn: 'কোরআন তিলাওয়াত', type: 'boolean', weight: 15, icon: BookOpen },
    { id: 'tahajjud', name: 'Tahajjud Prayer', bn: 'তাহাজ্জুদ', type: 'boolean', weight: 20, icon: Moon },
    { id: 'fasting', name: 'Nafl Fasting', bn: 'নফল রোজা', type: 'boolean', weight: 20, icon: Sun },
    { id: 'help', name: 'Selfless Help', bn: 'নিঃস্বার্থ সাহায্য', type: 'boolean', weight: 10, icon: Shield },
    { id: 'truth', name: 'Spoke Only Truth', bn: 'মিথ্যা না বলা', type: 'boolean', weight: 10, icon: Check },
    { id: 'dhikr', name: 'Dhikr (Remembrance)', bn: 'জিকির', type: 'counter', weight: 1, icon: Activity },
    { id: 'durood', name: 'Durood Shareef', bn: 'দুরুদ শরীফ', type: 'counter', weight: 1, icon: Star },
    { id: 'tawbah', name: 'Tawbah (Repentance)', bn: 'তওবা', type: 'counter', weight: 2, icon: Award },
];

const BAD_DEEDS = [
    { id: 'lying', name: 'Lied', bn: 'মিথ্যা বলা', weight: 15, icon: Frown },
    { id: 'backbiting', name: 'Backbiting (Gheebah)', bn: 'গীবত করা', weight: 15, icon: AlertTriangle },
    { id: 'hurting', name: 'Hurt Someone', bn: 'কাউকে কষ্ট দেওয়া', weight: 30, icon: XCircle },
    { id: 'missedPrayer', name: 'Missed Obligatory Prayer', bn: 'ফরজ নামাজ কাজা', weight: 25, icon: Trash2 },
];

const INITIAL_DAY_DATA = {
    namaz: { fajr: false, dhuhr: false, asr: false, maghrib: false, isha: false },
    goodDeeds: { sadaqah: false, quran: false, tahajjud: false, fasting: false, help: false, truth: false, dhikr: 0, durood: 0, tawbah: 0 },
    badDeeds: { lying: 0, backbiting: 0, hurting: 0, missedPrayer: 0 },
    customGoodDeeds: [],
    customBadDeeds: []
};

const getTodayDateString = () => new Date().toLocaleDateString('en-CA'); // YYYY-MM-DD

// --- Main Application Component ---
export default function DeenTracker() {
    // State
    const [cycleStartDate, setCycleStartDate] = useState(getTodayDateString());
    const [currentDate, setCurrentDate] = useState(getTodayDateString());
    const [history, setHistory] = useState([]);
    const [todayData, setTodayData] = useState(INITIAL_DAY_DATA);
    
    // New States
    const [isDarkMode, setIsDarkMode] = useState(false);
    const [lang, setLang] = useState('en');
    const [showSettings, setShowSettings] = useState(false);
    const [customGoodText, setCustomGoodText] = useState("");
    const [customBadText, setCustomBadText] = useState("");

    const [isShaking, setIsShaking] = useState(false);
    const [particles, setParticles] = useState([]);
    const [activeTab, setActiveTab] = useState('dashboard');

    // Initialization & LocalStorage Sync
    useEffect(() => {
        // Inject styles
        const styleSheet = document.createElement("style");
        styleSheet.innerText = customStyles;
        document.head.appendChild(styleSheet);

        const savedData = localStorage.getItem('deenTrackerData');
        if (savedData) {
            try {
                const parsed = JSON.parse(savedData);
                const today = getTodayDateString();
                
                // Check if cycle is over (8th day)
                const start = new Date(parsed.cycleStartDate);
                const now = new Date(today);
                const diffDays = Math.floor((now - start) / (1000 * 60 * 60 * 24));
                
                if (diffDays >= 7) {
                // Reset for fresh week
                setCycleStartDate(today);
                setCurrentDate(today);
                setHistory([]);
                setTodayData(INITIAL_DAY_DATA);
            } else if (parsed.currentDate !== today) {
                // New day within cycle
                setHistory(prev => [...parsed.history, { date: parsed.currentDate, data: parsed.todayData }]);
                setCurrentDate(today);
                setTodayData(INITIAL_DAY_DATA);
                setCycleStartDate(parsed.cycleStartDate);
            } else {
                // Same day reload
                setCycleStartDate(parsed.cycleStartDate);
                setCurrentDate(parsed.currentDate);
                setHistory(parsed.history || []);
                
                // Backwards compatibility for data structure
                setTodayData({
                    ...INITIAL_DAY_DATA,
                    ...(parsed.todayData || {}),
                    customGoodDeeds: parsed.todayData?.customGoodDeeds || [],
                    customBadDeeds: parsed.todayData?.customBadDeeds || []
                });
            }

            if (parsed.isDarkMode !== undefined) setIsDarkMode(parsed.isDarkMode);
            if (parsed.lang !== undefined) setLang(parsed.lang);

        } catch (e) {
            console.error("Failed to parse data", e);
        }
    }
    return () => document.head.removeChild(styleSheet);
}, []);

// Save to LocalStorage on state change
useEffect(() => {
    const dataToSave = { cycleStartDate, currentDate, history, todayData, isDarkMode, lang };
    localStorage.setItem('deenTrackerData', JSON.stringify(dataToSave));
}, [cycleStartDate, currentDate, history, todayData, isDarkMode, lang]);

// Score Calculations
const namazScore = useMemo(() => {
        const completed = Object.values(todayData.namaz).filter(Boolean).length;
        return (completed / 5) * 100;
}, [todayData.namaz]);

const goodDeedsScore = useMemo(() => {
    let score = 0;
    GOOD_DEEDS.forEach(deed => {
        const value = todayData.goodDeeds[deed.id];
        if (deed.type === 'boolean' && value) score += deed.weight;
        if (deed.type === 'counter' && value > 0) score += (deed.weight * value);
    });
    (todayData.customGoodDeeds || []).forEach(d => { score += d.weight; });
    return Math.min(100, score); // Cap good deeds at 100% for calculation
}, [todayData.goodDeeds, todayData.customGoodDeeds]);

const badDeedsPenalty = useMemo(() => {
    let penalty = 0;
    BAD_DEEDS.forEach(deed => {
        const value = todayData.badDeeds[deed.id];
        if (value > 0) penalty += (deed.weight * value);
    });
    (todayData.customBadDeeds || []).forEach(d => { penalty += d.weight; });
    return penalty;
}, [todayData.badDeeds, todayData.customBadDeeds]);

const overallScore = useMemo(() => {
        const baseScore = (namazScore * 0.5) + (goodDeedsScore * 0.5);
        const finalScore = Math.max(0, Math.min(100, baseScore - badDeedsPenalty));
        return Math.round(finalScore);
    }, [namazScore, goodDeedsScore, badDeedsPenalty]);

    // Dynamic Theme Color Calculation
    // Hue: 0 is Red, 120 is Green.
    const dynamicHue = Math.max(0, Math.min(120, (overallScore / 100) * 120));
    const themeBg = `hsl(${dynamicHue}, 85%, 96%)`;
    const themeCardBg = `hsl(${dynamicHue}, 40%, 99%)`;
    const themeBorder = `hsl(${dynamicHue}, 60%, 80%)`;
    const themeText = `hsl(${dynamicHue}, 70%, 25%)`;
    const themeAccent = `hsl(${dynamicHue}, 70%, 45%)`;

    // Actions & Animations
    const triggerSuccessAnimation = (e) => {
        const rect = e.target.getBoundingClientRect();
        const x = rect.left + rect.width / 2;
        const y = rect.top + rect.height / 2;
        
        const newParticles = Array.from({ length: 8 }).map((_, i) => ({
            id: Date.now() + i,
            x: x + (Math.random() - 0.5) * 40,
            y: y + (Math.random() - 0.5) * 40,
            color: ['#4ade80', '#22c55e', '#16a34a', '#fbbf24'][Math.floor(Math.random() * 4)]
        }));

        setParticles(prev => [...prev, ...newParticles]);
        setTimeout(() => {
            setParticles(prev => prev.filter(p => !newParticles.find(np => np.id === p.id)));
        }, 1200);
    };

    const triggerWarningAnimation = () => {
        setIsShaking(true);
        setTimeout(() => setIsShaking(false), 400);
    };

    const toggleNamaz = (id, e) => {
        const newValue = !todayData.namaz[id];
        setTodayData(prev => ({
            ...prev,
            namaz: { ...prev.namaz, [id]: newValue }
        }));
        if (newValue) triggerSuccessAnimation(e);
    };

    const toggleGoodDeed = (id, type, e) => {
        setTodayData(prev => {
            const current = prev.goodDeeds[id];
            const newValue = type === 'boolean' ? !current : current + 1;
            if (type === 'boolean' && !current) triggerSuccessAnimation(e);
            if (type === 'counter') triggerSuccessAnimation(e);
            return { ...prev, goodDeeds: { ...prev.goodDeeds, [id]: newValue } };
        });
    };

    const addBadDeed = (id) => {
        setTodayData(prev => ({
            ...prev,
            badDeeds: { ...prev.badDeeds, [id]: prev.badDeeds[id] + 1 }
        }));
        triggerWarningAnimation();
    };

    const removeBadDeed = (id) => {
        setTodayData(prev => ({
            ...prev,
            badDeeds: { ...prev.badDeeds, [id]: Math.max(0, prev.badDeeds[id] - 1) }
        }));
    };

    const decrementGoodDeed = (id) => {
        setTodayData(prev => ({
            ...prev,
            goodDeeds: { ...prev.goodDeeds, [id]: Math.max(0, prev.goodDeeds[id] - 1) }
        }));
    };

    const removeCustomGoodDeed = (index) => {
        setTodayData(prev => ({
            ...prev,
            customGoodDeeds: prev.customGoodDeeds.filter((_, i) => i !== index)
        }));
    };

    const removeCustomBadDeed = (index) => {
        setTodayData(prev => ({
            ...prev,
            customBadDeeds: prev.customBadDeeds.filter((_, i) => i !== index)
        }));
    };

    const handleAddCustomGoodDeed = (e) => {
        e.preventDefault();
        if(!customGoodText.trim()) return;
        // Dynamic weight based on string length (proxy for depth/effort)
        const weight = Math.min(10, Math.max(2, Math.floor(customGoodText.length / 3)));
        setTodayData(prev => ({
            ...prev,
            customGoodDeeds: [...(prev.customGoodDeeds || []), { text: customGoodText, weight }]
        }));
        setCustomGoodText("");
        triggerSuccessAnimation(e);
    };

    const handleAddCustomBadDeed = (e) => {
        e.preventDefault();
        if(!customBadText.trim()) return;
        // Dynamic penalty based on string length
        const weight = Math.min(15, Math.max(3, Math.floor(customBadText.length / 2)));
        setTodayData(prev => ({
            ...prev,
            customBadDeeds: [...(prev.customBadDeeds || []), { text: customBadText, weight }]
        }));
        setCustomBadText("");
        triggerWarningAnimation();
    };

    const t = T[lang];

    // Dark Mode Adjustments
    const finalBg = isDarkMode ? `hsl(${dynamicHue}, 60%, 10%)` : themeBg;
    const finalCardBg = isDarkMode ? `hsl(${dynamicHue}, 40%, 15%)` : themeCardBg;
    const finalBorder = isDarkMode ? `hsl(${dynamicHue}, 40%, 25%)` : themeBorder;
    const finalBgElement = isDarkMode ? `hsl(${dynamicHue}, 30%, 20%)` : 'white';
    const finalHoverBg = isDarkMode ? `hsl(${dynamicHue}, 30%, 25%)` : '#f9fafb';
    const textPrimary = isDarkMode ? `hsl(${dynamicHue}, 20%, 90%)` : themeText;
    const textSecondary = isDarkMode ? `hsl(${dynamicHue}, 20%, 70%)` : '#4b5563';

    // Components
    const ProgressBar = ({ label, value, colorClass }) => (
        <div className="w-full mb-4">
            <div className="flex justify-between mb-1">
                <span className="text-sm font-semibold" style={{ color: textSecondary }}>{label}</span>
                <span className="text-sm font-bold" style={{ color: themeAccent }}>{Math.round(value)}%</span>
            </div>
            <div className={`w-full rounded-full h-3 ${isDarkMode ? 'bg-gray-700' : 'bg-gray-200'}`}>
                <div 
                    className={`h-3 rounded-full transition-all duration-700 ${colorClass}`}
                    style={{ width: `${value}%`, backgroundColor: themeAccent }}
                ></div>
            </div>
        </div>
    );

    return (
        <div 
            className={`min-h-screen transition-colors duration-700 ease-in-out font-sans pb-20 ${isShaking ? 'animate-shake' : ''}`}
            style={{ backgroundColor: finalBg, color: textPrimary }}
        >
            {/* Particles Overlay */}
            {particles.map(p => (
                <div 
                    key={p.id} 
                    className="particle z-50 rounded-full"
                    style={{ 
                        left: p.x, top: p.y, 
                        width: '8px', height: '8px', 
                        backgroundColor: p.color 
                    }}
                />
            ))}

            {/* Header */}
            <header className="pt-10 pb-6 px-6 shadow-sm rounded-b-3xl transition-colors duration-700 relative" style={{ backgroundColor: finalCardBg }}>
                <button 
                    onClick={() => setShowSettings(true)}
                    className="absolute top-6 right-6 p-2 rounded-full transition-colors opacity-70 hover:opacity-100"
                    style={{ backgroundColor: isDarkMode ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.05)' }}
                >
                    <Settings size={20} />
                </button>
                <div className="max-w-2xl mx-auto flex items-center justify-between">
                    <div>
                        <h1 className="text-3xl font-extrabold tracking-tight" style={{ color: textPrimary }}>{t.appTitle}</h1>
                        <p className="text-sm opacity-80 font-medium" style={{ color: themeAccent }}>
                            {t.day} {history.length + 1} {t.of} 7 • {new Date(currentDate).toLocaleDateString(lang === 'bn' ? 'bn-BD' : 'en-US', { weekday: 'long', month: 'short', day: 'numeric'})}
                        </p>
                    </div>
                    {/* Circular Overall Score */}
                    <div className="relative flex items-center justify-center w-20 h-20 rounded-full shadow-lg border-4 transition-colors duration-700" style={{ borderColor: themeAccent, backgroundColor: finalBgElement }}>
                        <span className="text-xl font-black" style={{ color: textPrimary }}>{overallScore}%</span>
                    </div>
                </div>
            </header>

            {/* Settings Modal */}
            {showSettings && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 backdrop-blur-sm p-4">
                    <div className="rounded-2xl shadow-xl w-full max-w-sm p-6 space-y-6" style={{ backgroundColor: finalCardBg, color: textPrimary }}>
                        <div className="flex justify-between items-center border-b pb-3" style={{ borderColor: finalBorder }}>
                            <h3 className="text-xl font-bold flex items-center gap-2">
                                <Settings size={22} /> {t.settings}
                            </h3>
                            <button onClick={() => setShowSettings(false)} className="p-1 opacity-70 hover:opacity-100">
                                <X size={20} />
                            </button>
                        </div>
                        
                        <div className="space-y-4">
                            <div className="flex items-center justify-between">
                                <span className="font-medium">{t.darkMode}</span>
                                <button 
                                    onClick={() => setIsDarkMode(!isDarkMode)}
                                    className={`w-12 h-6 rounded-full p-1 transition-colors ${isDarkMode ? 'bg-emerald-500' : 'bg-gray-300'}`}
                                >
                                    <div className={`w-4 h-4 rounded-full bg-white transition-transform ${isDarkMode ? 'translate-x-6' : 'translate-x-0'}`}></div>
                                </button>
                            </div>
                            
                            <div className="flex items-center justify-between">
                                <span className="font-medium">{t.language}</span>
                                <div className="flex gap-2 p-1 rounded-lg" style={{ backgroundColor: finalBgElement }}>
                                    <button 
                                        onClick={() => setLang('en')}
                                        className={`px-3 py-1 text-sm rounded-md font-bold transition-colors ${lang === 'en' ? 'bg-emerald-500 text-white' : 'opacity-70'}`}
                                    >EN</button>
                                    <button 
                                        onClick={() => setLang('bn')}
                                        className={`px-3 py-1 text-sm rounded-md font-bold transition-colors ${lang === 'bn' ? 'bg-emerald-500 text-white' : 'opacity-70'}`}
                                    >বাং</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* Main Content */}
            <main className="max-w-2xl mx-auto px-4 mt-6 space-y-6">
                
                {/* Navigation Tabs */}
                <div className="flex rounded-xl shadow-sm p-1" style={{ backgroundColor: finalCardBg }}>
                    {['dashboard', 'tasks', 'history'].map(tab => (
                        <button
                            key={tab}
                            onClick={() => setActiveTab(tab)}
                            className={`flex-1 py-2 text-sm font-bold capitalize rounded-lg transition-all ${activeTab === tab ? 'shadow-md transform scale-[1.02]' : 'opacity-60'}`}
                            style={{ 
                                backgroundColor: activeTab === tab ? themeAccent : 'transparent',
                                color: activeTab === tab ? 'white' : 'inherit'
                            }}
                        >
                            {t[tab]}
                        </button>
                    ))}
                </div>

                {/* Dashboard Tab */}
                {activeTab === 'dashboard' && (
                    <div className="space-y-6 animate-pop">
                        <div className="p-6 rounded-2xl shadow-sm border transition-colors duration-700" style={{ backgroundColor: finalCardBg, borderColor: finalBorder }}>
                            <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                                <TrendingUp size={20} /> {t.summary}
                            </h2>
                            <ProgressBar label={t.namazComplete} value={namazScore} />
                            <ProgressBar label={t.goodAchieved} value={goodDeedsScore} />
                            
                            {badDeedsPenalty > 0 && (
                                <div className="mt-4 p-3 bg-red-100 text-red-800 rounded-lg text-sm font-medium flex items-start gap-2">
                                    <AlertTriangle size={18} className="shrink-0 mt-0.5" />
                                    <span>{lang === 'en' ? t.penalties : t.penalties + badDeedsPenalty + ' ' + t.pts + ')'} {lang === 'en' ? '-' + badDeedsPenalty + ' ' + t.pts + ' ' : ''} {t.penaltyInfo}</span>
                                </div>
                            )}
                        </div>
                    </div>
                )}

                {/* Tasks Tab */}
                {activeTab === 'tasks' && (
                    <div className="space-y-6 animate-pop">
                        {/* Namaz Section */}
                        <section className="p-5 rounded-2xl shadow-sm border" style={{ backgroundColor: finalCardBg, borderColor: finalBorder }}>
                            <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                                <Moon size={22} style={{ color: themeAccent }} /> {t.prayers}
                            </h2>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                {NAMAZ_LIST.map(prayer => (
                                    <button
                                        key={prayer.id}
                                        onClick={(e) => toggleNamaz(prayer.id, e)}
                                        className={`flex items-center justify-between p-4 rounded-xl border-2 transition-all ${
                                            todayData.namaz[prayer.id] 
                                            ? 'shadow-md border-transparent text-white' 
                                            : ''
                                        }`}
                                        style={{ 
                                            backgroundColor: todayData.namaz[prayer.id] ? themeAccent : finalHoverBg,
                                            borderColor: todayData.namaz[prayer.id] ? 'transparent' : finalBorder,
                                            color: todayData.namaz[prayer.id] ? '#fff' : textPrimary
                                        }}
                                    >
                                        <div className="flex items-center gap-3 font-semibold text-lg">
                                            <prayer.icon size={20} className={todayData.namaz[prayer.id] ? 'opacity-90' : 'opacity-60'} />
                                            {lang === 'bn' ? prayer.bn : prayer.name}
                                        </div>
                                        <div className={`w-6 h-6 rounded-full flex items-center justify-center border-2 ${
                                            todayData.namaz[prayer.id] ? 'border-white bg-white text-current' : 'border-gray-400'
                                        }`} style={{ color: todayData.namaz[prayer.id] ? themeAccent : 'transparent' }}>
                                            {todayData.namaz[prayer.id] && <Check size={14} strokeWidth={4} />}
                                        </div>
                                    </button>
                                ))}
                            </div>
                        </section>

                        {/* Good Deeds Section */}
                        <section className="p-5 rounded-2xl shadow-sm border" style={{ backgroundColor: finalCardBg, borderColor: finalBorder }}>
                            <h2 className="text-xl font-bold mb-4 flex items-center gap-2 text-emerald-600">
                                <Heart size={22} /> {t.goodDeeds}
                            </h2>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                {GOOD_DEEDS.map(deed => {
                                    const isDone = deed.type === 'boolean' ? todayData.goodDeeds[deed.id] : todayData.goodDeeds[deed.id] > 0;
                                    return (
                                        <div
                                            key={deed.id}
                                            onClick={(e) => toggleGoodDeed(deed.id, deed.type, e)}
                                            className="flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer"
                                            style={{
                                                backgroundColor: isDone ? (isDarkMode ? '#064e3b' : '#ecfdf5') : finalHoverBg,
                                                borderColor: isDone ? '#10b981' : finalBorder,
                                                color: isDone ? (isDarkMode ? '#34d399' : '#065f46') : textPrimary
                                            }}
                                        >
                                            <div className="flex items-center gap-3">
                                                <div className="p-2 rounded-lg" style={{ backgroundColor: isDone ? 'rgba(16,185,129,0.2)' : finalBgElement }}>
                                                    <deed.icon size={18} style={{ color: isDone ? '#10b981' : textSecondary }} />
                                                </div>
                                                <div className="text-left">
                                                    <div className="font-semibold text-sm">{lang === 'bn' ? deed.bn : deed.name}</div>
                                                    <div className="text-xs opacity-70">+{deed.weight} {t.pts}</div>
                                                </div>
                                            </div>
                                            {deed.type === 'boolean' ? (
                                                <div className={`w-5 h-5 rounded flex items-center justify-center ${isDone ? 'bg-emerald-500 text-white' : 'bg-gray-300 text-transparent'}`}>
                                                    <Check size={14} strokeWidth={3} />
                                                </div>
                                            ) : (
                                                <div className="flex items-center gap-2">
                                                    {todayData.goodDeeds[deed.id] > 0 && (
                                                        <>
                                                            <button 
                                                                onClick={(e) => { e.stopPropagation(); decrementGoodDeed(deed.id); }} 
                                                                className="p-1 rounded-full bg-emerald-100 text-emerald-700 hover:bg-emerald-200 dark:bg-emerald-800 dark:text-emerald-200 transition-colors"
                                                            >
                                                                <Minus size={14}/>
                                                            </button>
                                                            <span className="font-bold px-2 py-0.5 rounded-full text-xs" style={{ backgroundColor: 'rgba(16,185,129,0.2)', color: '#10b981' }}>
                                                                {todayData.goodDeeds[deed.id]}
                                                            </span>
                                                        </>
                                                    )}
                                                    <button 
                                                        onClick={(e) => { e.stopPropagation(); toggleGoodDeed(deed.id, 'counter', e); }}
                                                        className="rounded-full p-0.5"
                                                    >
                                                        <Plus size={18} style={{ color: '#10b981', backgroundColor: 'rgba(16,185,129,0.2)' }} />
                                                    </button>
                                                </div>
                                            )}
                                        </div>
                                    );
                                })}
                                
                                {/* Render Custom Good Deeds */}
                                {(todayData.customGoodDeeds || []).map((d, i) => (
                                    <div key={i} className="flex items-center justify-between p-3 rounded-xl border border-emerald-500 bg-emerald-50 dark:bg-emerald-900"
                                        style={{ backgroundColor: isDarkMode ? '#064e3b' : '#ecfdf5', color: isDarkMode ? '#34d399' : '#065f46' }}>
                                        <div className="flex items-center gap-3">
                                            <div className="p-2 rounded-lg" style={{ backgroundColor: 'rgba(16,185,129,0.2)' }}>
                                                <Star size={18} style={{ color: '#10b981' }} />
                                            </div>
                                            <div className="text-left">
                                                <div className="font-semibold text-sm">{d.text}</div>
                                                <div className="text-xs opacity-70">+{d.weight} {t.pts}</div>
                                            </div>
                                        </div>
                                        <button 
                                            onClick={() => removeCustomGoodDeed(i)}
                                            className="w-7 h-7 rounded-full flex items-center justify-center bg-red-100 text-red-500 hover:bg-red-200 dark:bg-red-900/50 transition-colors"
                                            title="Delete"
                                        >
                                            <Trash2 size={14} />
                                        </button>
                                    </div>
                                ))}
                            </div>
                            
                            {/* Add Custom Good Deed Input */}
                            <form onSubmit={handleAddCustomGoodDeed} className="mt-4 flex gap-2">
                                <input 
                                    type="text" 
                                    value={customGoodText}
                                    onChange={(e) => setCustomGoodText(e.target.value)}
                                    placeholder={t.customPlaceholder}
                                    className="flex-1 px-3 py-2 rounded-lg border focus:outline-none focus:ring-2 focus:ring-emerald-500"
                                    style={{ backgroundColor: finalBgElement, borderColor: finalBorder, color: textPrimary }}
                                />
                                <button type="submit" className="px-4 py-2 bg-emerald-500 text-white rounded-lg font-semibold flex items-center gap-1 hover:bg-emerald-600 transition-colors">
                                    <Send size={16} /> {t.add}
                                </button>
                            </form>
                        </section>

                        {/* Bad Deeds Section */}
                        <section className="p-5 rounded-2xl shadow-sm border relative overflow-hidden" style={{ backgroundColor: finalCardBg, borderColor: isDarkMode ? '#7f1d1d' : '#fee2e2' }}>
                            <div className="absolute top-0 left-0 w-2 h-full bg-red-500"></div>
                            <h2 className="text-xl font-bold mb-2 flex items-center gap-2 text-red-600 pl-2">
                                <AlertTriangle size={22} /> {t.badDeeds}
                            </h2>
                            <p className="text-xs mb-4 pl-2" style={{ color: textSecondary }}>{t.badDesc}</p>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pl-2">
                                {BAD_DEEDS.map(deed => (
                                    <div
                                        key={deed.id}
                                        onClick={() => addBadDeed(deed.id)}
                                        className="flex items-center justify-between p-3 rounded-xl border transition-colors text-left cursor-pointer hover:bg-red-50 dark:hover:bg-red-900/30"
                                        style={{ backgroundColor: finalHoverBg, borderColor: finalBorder }}
                                    >
                                        <div className="flex items-center gap-3">
                                            <deed.icon size={18} className="text-red-500" />
                                            <div>
                                                <div className="font-medium text-sm">{lang === 'bn' ? deed.bn : deed.name}</div>
                                                <div className="text-xs text-red-500 font-semibold">-{deed.weight} {t.pts}</div>
                                            </div>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            {todayData.badDeeds[deed.id] > 0 ? (
                                                <>
                                                    <button 
                                                        onClick={(e) => { e.stopPropagation(); removeBadDeed(deed.id); }}
                                                        className="p-1 rounded-full bg-red-200 text-red-700 hover:bg-red-300 dark:bg-red-800 dark:text-red-300 transition-colors"
                                                    >
                                                        <Minus size={14} />
                                                    </button>
                                                    <span className="bg-red-100 text-red-700 font-bold px-2 py-1 rounded text-xs dark:bg-red-900 dark:text-red-300">
                                                        {todayData.badDeeds[deed.id]}
                                                    </span>
                                                </>
                                            ) : (
                                                <Plus size={16} style={{ color: textSecondary }} />
                                            )}
                                        </div>
                                    </div>
                                ))}
                                
                                {/* Render Custom Bad Deeds */}
                                {(todayData.customBadDeeds || []).map((d, i) => (
                                    <div key={i} className="flex items-center justify-between p-3 rounded-xl border border-red-500 bg-red-50 dark:bg-red-900 text-red-700 dark:text-red-300">
                                        <div className="flex items-center gap-3">
                                            <Frown size={18} className="text-red-500" />
                                            <div>
                                                <div className="font-medium text-sm">{d.text}</div>
                                                <div className="text-xs text-red-500 font-semibold">-{d.weight} {t.pts}</div>
                                            </div>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <span className="font-bold px-2 py-1 rounded text-xs bg-red-200 dark:bg-red-800 text-red-700 dark:text-red-300">1</span>
                                            <button 
                                                onClick={() => removeCustomBadDeed(i)}
                                                className="w-7 h-7 rounded-full flex items-center justify-center bg-red-200 text-red-700 hover:bg-red-300 dark:bg-red-800 dark:text-red-300 transition-colors"
                                                title="Delete"
                                            >
                                                <Trash2 size={14} />
                                            </button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                            
                            {/* Add Custom Bad Deed Input */}
                            <form onSubmit={handleAddCustomBadDeed} className="mt-4 pl-2 flex gap-2">
                                <input 
                                    type="text" 
                                    value={customBadText}
                                    onChange={(e) => setCustomBadText(e.target.value)}
                                    placeholder={t.customPlaceholder}
                                    className="flex-1 px-3 py-2 rounded-lg border focus:outline-none focus:ring-2 focus:ring-red-500"
                                    style={{ backgroundColor: finalBgElement, borderColor: finalBorder, color: textPrimary }}
                                />
                                <button type="submit" className="px-4 py-2 bg-red-500 text-white rounded-lg font-semibold flex items-center gap-1 hover:bg-red-600 transition-colors">
                                    <Send size={16} /> {t.add}
                                </button>
                            </form>
                        </section>
                    </div>
                )}

                {/* History Tab */}
                {activeTab === 'history' && (
                    <div className="space-y-4 animate-pop">
                        <div className="p-6 rounded-2xl shadow-sm border" style={{ backgroundColor: finalCardBg, borderColor: finalBorder }}>
                            <h2 className="text-xl font-bold mb-2 flex items-center gap-2">
                                <Calendar size={20} /> {t.historyTitle}
                            </h2>
                            <p className="text-sm mb-6" style={{ color: textSecondary }}>{t.historyDesc}</p>
                            
                            {history.length === 0 ? (
                                <div className="text-center py-8 opacity-60">
                                    <Calendar size={48} className="mx-auto mb-3 opacity-20" />
                                    <p>{t.noHistory}</p>
                                </div>
                            ) : (
                                <div className="space-y-3">
                                    {history.map((day, idx) => {
                                        // Score calculation for history item
                                        const nScore = (Object.values(day.data.namaz).filter(Boolean).length / 5) * 100;
                                        let gScore = 0;
                                        GOOD_DEEDS.forEach(d => {
                                            const v = day.data.goodDeeds[d.id];
                                            if (d.type === 'boolean' && v) gScore += d.weight;
                                            if (d.type === 'counter' && v > 0) gScore += (d.weight * v);
                                        });
                                        (day.data.customGoodDeeds || []).forEach(d => { gScore += d.weight; });
                                        gScore = Math.min(100, gScore);
                                        
                                        let bPenalty = 0;
                                        BAD_DEEDS.forEach(d => {
                                            const v = day.data.badDeeds[d.id];
                                            if (v > 0) bPenalty += (d.weight * v);
                                        });
                                        (day.data.customBadDeeds || []).forEach(d => { bPenalty += d.weight; });
                                        
                                        const finalScore = Math.round(Math.max(0, Math.min(100, (nScore * 0.5 + gScore * 0.5) - bPenalty)));
                                        const hHue = Math.max(0, Math.min(120, (finalScore / 100) * 120));
                                        
                                        return (
                                            <div key={idx} className="flex items-center justify-between p-3 rounded-lg border" style={{ backgroundColor: finalHoverBg, borderColor: finalBorder }}>
                                                <div>
                                                    <div className="font-semibold text-sm">
                                                        {new Date(day.date).toLocaleDateString(lang === 'bn' ? 'bn-BD' : 'en-US', { weekday: 'short', month: 'short', day: 'numeric'})}
                                                    </div>
                                                    <div className="text-xs" style={{ color: textSecondary }}>{t.day} {idx + 1}</div>
                                                </div>
                                                <div 
                                                    className="px-3 py-1 rounded-full text-sm font-bold text-white shadow-sm"
                                                    style={{ backgroundColor: `hsl(${hHue}, 60%, 45%)` }}
                                                >
                                                    {finalScore}%
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                            )}
                        </div>
                    </div>
                )}
            </main>
        </div>
    );
}
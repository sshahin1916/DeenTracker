DEEN TRACKER - Android App Project

এই ফোল্ডারটি আপনার HTML/React কোড থেকে Android APK বানানোর জন্য প্রস্তুত করা হয়েছে।

Windows PC-তে করণীয়:
1) Node.js LTS, Android Studio এবং Android SDK ইনস্টল করুন।
2) এই ফোল্ডারে Terminal খুলুন।
3) চালান: npm install
4) চালান: npm run build
5) চালান: npx cap add android
   (আগে android ফোল্ডার থাকলে এই ধাপ বাদ দিন)
6) চালান: npx cap sync android
7) চালান: npx cap open android
8) Android Studio-তে Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।

গুরুত্বপূর্ণ:
- APK তৈরি করতে Android SDK/Android Studio-সহ PC প্রয়োজন।
- এই পরিবেশে Android SDK নেই, তাই এখানে সরাসরি APK compile করা যায়নি।
- অ্যাপের ডেটা বর্তমানে browser localStorage-এ থাকে; WebView-এও একই ডিভাইসে লোকালি সংরক্ষিত হবে।
